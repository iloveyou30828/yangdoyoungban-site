import { useState } from 'react';

function App() {
  const [contents, setContents] = useState([]);
  const [inputValue, setInputValue] = useState('');

  const handleAddText = () => {
    if (inputValue.trim()) {
      setContents([...contents, { type: 'text', value: inputValue }]);
      setInputValue('');
    }
  };

  const handleAddImage = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setContents([...contents, { type: 'image', value: reader.result }]);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div style={{ minHeight: '100vh', padding: '2rem', backgroundColor: '#f3f4f6' }}>
      <h1 style={{ fontSize: '3rem', fontWeight: 'bold', textAlign: 'center', marginBottom: '2rem' }}>
        양두영반
      </h1>
      <div style={{ maxWidth: '640px', margin: '0 auto' }}>
        <div style={{ display: 'flex', gap: '0.5rem', marginBottom: '1rem' }}>
          <input
            style={{ flexGrow: 1, padding: '0.5rem' }}
            placeholder="적고 싶은 말을 입력하세요"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
          />
          <button onClick={handleAddText}>+ 글 추가</button>
          <label>
            <input type="file" accept="image/*" onChange={handleAddImage} style={{ display: 'none' }} />
            <button>+ 사진 추가</button>
          </label>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          {contents.map((item, index) => (
            <div key={index} style={{ backgroundColor: '#fff', padding: '1rem', borderRadius: '1rem' }}>
              {item.type === 'text' ? (
                <p style={{ fontSize: '1.2rem' }}>{item.value}</p>
              ) : (
                <img src={item.value} alt="업로드된 이미지" style={{ maxWidth: '100%', borderRadius: '0.5rem' }} />
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default App;